<?php



// register post type team
add_action( 'init', 'register_atena_Gallery' );
function register_atena_Gallery() {
    
    $labels = array( 
        'name' => __( 'Gallery', 'atena' ),
        'singular_name' => __( 'Gallery', 'atena' ),
        'add_new' => __( 'Add New Gallery', 'atena' ),
        'add_new_item' => __( 'Add New Gallery', 'atena' ),
        'edit_item' => __( 'Edit Gallery', 'atena' ),
        'new_item' => __( 'New Gallery', 'atena' ),
        'view_item' => __( 'View Gallery', 'atena' ),
        'search_items' => __( 'Search Gallery', 'atena' ),
        'not_found' => __( 'No Gallery found', 'atena' ),
        'not_found_in_trash' => __( 'No Gallery found in Trash', 'atena' ),
        'parent_item_colon' => __( 'Parent Gallery:', 'atena' ),
        'menu_name' => __( 'Gallery', 'atena' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Gallery',
        'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),
        'taxonomies' => array( 'Gallery' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => get_stylesheet_directory_uri(). '/img/admin_ico.png', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
    );

    register_post_type( 'Gallery', $args );
}




// register post type team
add_action( 'init', 'register_atena_Teacher' );
function register_atena_Teacher() {
    
    $labels = array( 
        'name' => __( 'Teacher', 'atena' ),
        'singular_name' => __( 'Teacher', 'atena' ),
        'add_new' => __( 'Add New Teacher', 'atena' ),
        'add_new_item' => __( 'Add New Teacher', 'atena' ),
        'edit_item' => __( 'Edit Teacher', 'atena' ),
        'new_item' => __( 'New Teacher', 'atena' ),
        'view_item' => __( 'View Teacher', 'atena' ),
        'search_items' => __( 'Search Teacher', 'atena' ),
        'not_found' => __( 'No Teacher found', 'atena' ),
        'not_found_in_trash' => __( 'No Teacher found in Trash', 'atena' ),
        'parent_item_colon' => __( 'Parent Teacher:', 'atena' ),
        'menu_name' => __( 'Teacher', 'atena' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Teacher',
        'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),
        'taxonomies' => array( 'Teacher', 'subject' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => get_stylesheet_directory_uri(). '/img/admin_ico.png', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
    );

    register_post_type( 'Teacher', $args );
}


add_action( 'init', 'create_Subject_hierarchical_taxonomy', 0 );

//create a custom taxonomy name it Skillss for your posts

function create_Subject_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI

  $labels = array(
    'name' => __( 'Subject', 'travelia' ),
    'singular_name' => __( 'Subject', 'travelia' ),
    'search_items' =>  __( 'Search Subject','travelia' ),
    'all_items' => __( 'All Subject','travelia' ),
    'parent_item' => __( 'Parent Subject','travelia' ),
    'parent_item_colon' => __( 'Parent Subject:','travelia' ),
    'edit_item' => __( 'Edit Subject','travelia' ), 
    'update_item' => __( 'Update Subject','travelia' ),
    'add_new_item' => __( 'Add New Subject','travelia' ),
    'new_item_name' => __( 'New Subject Name','travelia' ),
    'menu_name' => __( 'Subject','travelia' ),
  );     

// Now register the taxonomy

  register_taxonomy('subject',array('Teacher'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'subject' ),
  ));

}




// register post type team
add_action( 'init', 'register_atena_Course' );
function register_atena_Course() {
    
    $labels = array( 
        'name' => __( 'Course', 'atena' ),
        'singular_name' => __( 'Course', 'atena' ),
        'add_new' => __( 'Add New Course', 'atena' ),
        'add_new_item' => __( 'Add New Course', 'atena' ),
        'edit_item' => __( 'Edit Course', 'atena' ),
        'new_item' => __( 'New Course', 'atena' ),
        'view_item' => __( 'View Course', 'atena' ),
        'search_items' => __( 'Search Course', 'atena' ),
        'not_found' => __( 'No Course found', 'atena' ),
        'not_found_in_trash' => __( 'No Course found in Trash', 'atena' ),
        'parent_item_colon' => __( 'Parent Course:', 'atena' ),
        'menu_name' => __( 'Course', 'atena' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Course',
        'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),
        'taxonomies' => array( 'Course', 'type' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => get_stylesheet_directory_uri(). '/img/admin_ico.png', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
    );

    register_post_type( 'Course', $args );
}


add_action( 'init', 'create_Type_hierarchical_taxonomy', 0 );

//create a custom taxonomy name it Skillss for your posts

function create_Type_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI

  $labels = array(
    'name' => __( 'Type', 'travelia' ),
    'singular_name' => __( 'Type', 'travelia' ),
    'search_items' =>  __( 'Search Type','travelia' ),
    'all_items' => __( 'All Type','travelia' ),
    'parent_item' => __( 'Parent Type','travelia' ),
    'parent_item_colon' => __( 'Parent Type:','travelia' ),
    'edit_item' => __( 'Edit Type','travelia' ), 
    'update_item' => __( 'Update Type','travelia' ),
    'add_new_item' => __( 'Add New Type','travelia' ),
    'new_item_name' => __( 'New Type Name','travelia' ),
    'menu_name' => __( 'Type','travelia' ),
  );     

// Now register the taxonomy

  register_taxonomy('type',array('Course'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'type' ),
  ));

}



// register post type team
add_action( 'init', 'register_atena_Event' );
function register_atena_Event() {
    
    $labels = array( 
        'name' => __( 'Event', 'atena' ),
        'singular_name' => __( 'Event', 'atena' ),
        'add_new' => __( 'Add New Event', 'atena' ),
        'add_new_item' => __( 'Add New Event', 'atena' ),
        'edit_item' => __( 'Edit Event', 'atena' ),
        'new_item' => __( 'New Event', 'atena' ),
        'view_item' => __( 'View Event', 'atena' ),
        'search_items' => __( 'Search Event', 'atena' ),
        'not_found' => __( 'No Event found', 'atena' ),
        'not_found_in_trash' => __( 'No Event found in Trash', 'atena' ),
        'parent_item_colon' => __( 'Parent Event:', 'atena' ),
        'menu_name' => __( 'Event', 'atena' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Event',
        'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),
        'taxonomies' => array( 'Event' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => get_stylesheet_directory_uri(). '/img/admin_ico.png', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
    );

    register_post_type( 'Event', $args );
}






?>